﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Фигура = new System.Windows.Forms.Label();
            this.Картина = new System.Windows.Forms.PictureBox();
            this.Выбор = new System.Windows.Forms.ComboBox();
            this.Добавить = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Тест = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Картина)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Тест)).BeginInit();
            this.SuspendLayout();
            // 
            // Фигура
            // 
            this.Фигура.AutoSize = true;
            this.Фигура.Location = new System.Drawing.Point(27, 24);
            this.Фигура.Name = "Фигура";
            this.Фигура.Size = new System.Drawing.Size(49, 13);
            this.Фигура.TabIndex = 0;
            this.Фигура.Text = "Фигура:";
            // 
            // Картина
            // 
            this.Картина.BackColor = System.Drawing.Color.White;
            this.Картина.Location = new System.Drawing.Point(30, 56);
            this.Картина.Name = "Картина";
            this.Картина.Size = new System.Drawing.Size(400, 400);
            this.Картина.TabIndex = 1;
            this.Картина.TabStop = false;
            this.Картина.Click += new System.EventHandler(this.Картина_Click);
            // 
            // Выбор
            // 
            this.Выбор.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Выбор.FormattingEnabled = true;
            this.Выбор.Items.AddRange(new object[] {
            "Квадрат",
            "Круг",
            "Треугольник"});
            this.Выбор.Location = new System.Drawing.Point(82, 21);
            this.Выбор.Name = "Выбор";
            this.Выбор.Size = new System.Drawing.Size(121, 21);
            this.Выбор.TabIndex = 2;
            this.Выбор.SelectedIndexChanged += new System.EventHandler(this.Выбор_SelectedIndexChanged);
            // 
            // Добавить
            // 
            this.Добавить.Location = new System.Drawing.Point(218, 21);
            this.Добавить.Name = "Добавить";
            this.Добавить.Size = new System.Drawing.Size(94, 21);
            this.Добавить.TabIndex = 3;
            this.Добавить.Text = "Добавить";
            this.Добавить.UseVisualStyleBackColor = true;
            this.Добавить.Click += new System.EventHandler(this.Добавить_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(318, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 21);
            this.button1.TabIndex = 4;
            this.button1.Text = "Удалить всё";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Тест
            // 
            this.Тест.BackColor = System.Drawing.Color.White;
            this.Тест.Location = new System.Drawing.Point(452, 56);
            this.Тест.Name = "Тест";
            this.Тест.Size = new System.Drawing.Size(400, 400);
            this.Тест.TabIndex = 6;
            this.Тест.TabStop = false;
            this.Тест.Click += new System.EventHandler(this.pictureBox1_Click);
            this.Тест.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Тест_MouseDown);
            this.Тест.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Тест_MouseMove);
            this.Тест.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Тест_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(582, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Перемещение квадрата:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 467);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Тест);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Добавить);
            this.Controls.Add(this.Выбор);
            this.Controls.Add(this.Картина);
            this.Controls.Add(this.Фигура);
            this.Name = "Form1";
            this.Text = "Фигуры";
            ((System.ComponentModel.ISupportInitialize)(this.Картина)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Тест)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Фигура;
        private System.Windows.Forms.PictureBox Картина;
        private System.Windows.Forms.ComboBox Выбор;
        private System.Windows.Forms.Button Добавить;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox Тест;
        private System.Windows.Forms.Label label1;
    }
}

