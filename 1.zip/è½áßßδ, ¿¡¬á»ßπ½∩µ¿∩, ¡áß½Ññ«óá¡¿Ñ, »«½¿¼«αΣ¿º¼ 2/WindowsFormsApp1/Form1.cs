﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
        }
        public float x, y;

        private void Выбор_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Картина_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Картина.Image = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        private Point start;
        private bool drawing = false;
        Bitmap bm = new Bitmap(400, 400);
        Bitmap bm2 = new Bitmap(400, 400);

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Тест_MouseDown(object sender, MouseEventArgs e)
        {
            drawing = true;
        }

        private void Тест_MouseUp(object sender, MouseEventArgs e)
        {
            drawing = false;
            Тест.Invalidate();
        }

        private void Тест_MouseMove(object sender, MouseEventArgs e)
        {
            if (!drawing) return;
            var start = new Point(e.X - 200, e.Y - 80); //по нормальному тут не должно быть констант(200 и 80) просто лень было все координаты менять
            bm2 = new Bitmap(bm);
            Тест.Image = bm2;
            var g = Graphics.FromImage(bm2);
            Pen pen = new Pen(Color.Black);
            g.DrawLine(pen, start.X + 200, start.Y + 100, start.X + 400, start.Y + 100);
            g.DrawLine(pen, start.X + 400, start.Y + 100, start.X + 400, start.Y + 300);
            g.DrawLine(pen, start.X + 200, start.Y + 100, start.X + 200, start.Y + 300);
            g.DrawLine(pen, start.X + 200, start.Y + 300, start.X + 400, start.Y + 300);
            g.Dispose();
            Тест.Invalidate();
        }

        private void Добавить_Click(object sender, EventArgs e)
        {
            if (Выбор.SelectedIndex == 0)
            {
                Random rnd = new Random();
                int value = rnd.Next(1, 300);
                Graphics gr = this.Картина.CreateGraphics();
                x = this.Картина.Width / 2;
                y = this.Картина.Height / 2;
                Pen myPen = new Pen(Color.FromArgb(rnd.Next(255), rnd.Next(255), rnd.Next(255)), 2);
                gr.DrawRectangle(myPen, value, value, 80, 80);
            }
            if (Выбор.SelectedIndex == 1)
            {
                Random rnd = new Random();
                int value = rnd.Next(1, 300);
                float radius = 40.0f;
                float diametr = radius * 2.0f;
                Graphics gr = this.Картина.CreateGraphics();
                x = this.Картина.Width / 2;
                y = this.Картина.Height / 2;
                Pen myPen = new Pen(Color.FromArgb(rnd.Next(255), rnd.Next(255), rnd.Next(255)), 2);
                gr.DrawEllipse(myPen, value, value, diametr, diametr);
            }
            if (Выбор.SelectedIndex == 2)
            {
                Graphics gr = this.Картина.CreateGraphics();
                Pen pen = new Pen(Color.Green, 2);
                x = this.Картина.Width;
                y = this.Картина.Height;
                Point[] points =
                {
                    new Point(360, 30),
                    new Point(330, 60),
                    new Point(390, 60),
                    new Point(360, 30)
                };
                gr.DrawLines(pen, points);
            }
        }
    }
}
