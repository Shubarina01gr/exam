﻿
namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Картина = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Картина)).BeginInit();
            this.SuspendLayout();
            // 
            // Картина
            // 
            this.Картина.BackColor = System.Drawing.Color.Black;
            this.Картина.Location = new System.Drawing.Point(47, 28);
            this.Картина.Name = "Картина";
            this.Картина.Size = new System.Drawing.Size(400, 400);
            this.Картина.TabIndex = 0;
            this.Картина.TabStop = false;
            this.Картина.Paint += new System.Windows.Forms.PaintEventHandler(this.Картина_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 450);
            this.Controls.Add(this.Картина);
            this.Name = "Form1";
            this.Text = "#2";
            ((System.ComponentModel.ISupportInitialize)(this.Картина)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Картина;
    }
}

